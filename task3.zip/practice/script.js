// DOM Elements
const modeSelection = document.getElementById('modeSelection');
const pvpBtn = document.getElementById('pvpBtn');
const pvcBtn = document.getElementById('pvcBtn');
const gameInfo = document.getElementById('gameInfo');
const gameBoard = document.getElementById('gameBoard');
const controls = document.getElementById('controls');
const cells = document.querySelectorAll('.cell');
const currentPlayerDisplay = document.getElementById('currentPlayer');
const restartBtn = document.getElementById('restartBtn');
const newGameBtn = document.getElementById('newGameBtn');
const resetBtn = document.getElementById('resetBtn');
const resultModal = document.getElementById('resultModal');
const resultText = document.getElementById('resultText');
const continueBtn = document.getElementById('continueBtn');
const scoreXDisplay = document.getElementById('scoreX');
const scoreODisplay = document.getElementById('scoreO');
const scoreDrawDisplay = document.getElementById('scoreDraw');
const player2Label = document.getElementById('player2Label');

// Game Variables
let currentPlayer = 'X';
let gameState = ['', '', '', '', '', '', '', '', ''];
let gameActive = false;
let gameMode = ''; // 'pvp' or 'pvc'
let scores = {
    X: 0,
    O: 0,
    draw: 0
};

// Winning Conditions
const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

// Event Listeners
pvpBtn.addEventListener('click', () => startGame('pvp'));
pvcBtn.addEventListener('click', () => startGame('pvc'));
restartBtn.addEventListener('click', restartGame);
newGameBtn.addEventListener('click', newGame);
resetBtn.addEventListener('click', resetScores);
continueBtn.addEventListener('click', closeModal);
cells.forEach(cell => cell.addEventListener('click', handleCellClick));

// Start Game
function startGame(mode) {
    gameMode = mode;
    modeSelection.style.display = 'none';
    gameInfo.style.display = 'block';
    gameBoard.style.display = 'grid';
    controls.style.display = 'flex';
    gameActive = true;
    
    if (mode === 'pvc') {
        player2Label.textContent = 'AI (O)';
    } else {
        player2Label.textContent = 'Player O';
    }
    
    updateCurrentPlayerDisplay();
}

// Handle Cell Click
function handleCellClick(event) {
    const clickedCell = event.target;
    const clickedCellIndex = parseInt(clickedCell.getAttribute('data-cell-index'));
    
    if (gameState[clickedCellIndex] !== '' || !gameActive) {
        return;
    }
    
    makeMove(clickedCellIndex, currentPlayer);
    
    if (gameActive && gameMode === 'pvc' && currentPlayer === 'O') {
        setTimeout(aiMove, 500);
    }
}

// Make Move
function makeMove(index, player) {
    gameState[index] = player;
    cells[index].textContent = player;
    cells[index].classList.add(player.toLowerCase());
    cells[index].classList.add('taken');
    
    checkResult();
}

// Check Result
function checkResult() {
    let roundWon = false;
    let winningCombination = [];
    
    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        if (gameState[a] === '' || gameState[b] === '' || gameState[c] === '') {
            continue;
        }
        if (gameState[a] === gameState[b] && gameState[b] === gameState[c]) {
            roundWon = true;
            winningCombination = [a, b, c];
            break;
        }
    }
    
    if (roundWon) {
        highlightWinningCells(winningCombination);
        gameActive = false;
        scores[currentPlayer]++;
        updateScores();
        setTimeout(() => {
            showResult(`Player ${currentPlayer} Wins!`);
        }, 500);
        return;
    }
    
    if (!gameState.includes('')) {
        gameActive = false;
        scores.draw++;
        updateScores();
        setTimeout(() => {
            showResult("It's a Draw!");
        }, 500);
        return;
    }
    
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    updateCurrentPlayerDisplay();
}

// Highlight Winning Cells
function highlightWinningCells(combination) {
    combination.forEach(index => {
        cells[index].classList.add('win');
    });
}

// Update Current Player Display
function updateCurrentPlayerDisplay() {
    if (gameMode === 'pvc' && currentPlayer === 'O') {
        currentPlayerDisplay.textContent = "AI's Turn";
    } else {
        currentPlayerDisplay.textContent = `Player ${currentPlayer}'s Turn`;
    }
}

// Update Scores
function updateScores() {
    scoreXDisplay.textContent = scores.X;
    scoreODisplay.textContent = scores.O;
    scoreDrawDisplay.textContent = scores.draw;
}

// Show Result Modal
function showResult(message) {
    resultText.textContent = message;
    resultModal.classList.add('show');
}

// Close Modal
function closeModal() {
    resultModal.classList.remove('show');
    restartGame();
}

// Restart Game
function restartGame() {
    gameState = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    gameActive = true;
    
    cells.forEach(cell => {
        cell.textContent = '';
        cell.classList.remove('x', 'o', 'taken', 'win');
    });
    
    updateCurrentPlayerDisplay();
}

// New Game (Back to Mode Selection)
function newGame() {
    restartGame();
    gameInfo.style.display = 'none';
    gameBoard.style.display = 'none';
    controls.style.display = 'none';
    modeSelection.style.display = 'block';
}

// Reset Scores
function resetScores() {
    scores = {
        X: 0,
        O: 0,
        draw: 0
    };
    updateScores();
}

// AI Move (Simple Algorithm)
function aiMove() {
    if (!gameActive) return;
    
    // Try to win
    let move = findWinningMove('O');
    if (move !== -1) {
        makeMove(move, 'O');
        return;
    }
    
    // Block player from winning
    move = findWinningMove('X');
    if (move !== -1) {
        makeMove(move, 'O');
        return;
    }
    
    // Take center if available
    if (gameState[4] === '') {
        makeMove(4, 'O');
        return;
    }
    
    // Take a corner
    const corners = [0, 2, 6, 8];
    const availableCorners = corners.filter(index => gameState[index] === '');
    if (availableCorners.length > 0) {
        const randomCorner = availableCorners[Math.floor(Math.random() * availableCorners.length)];
        makeMove(randomCorner, 'O');
        return;
    }
    
    // Take any available space
    const availableCells = gameState.map((cell, index) => cell === '' ? index : null).filter(val => val !== null);
    if (availableCells.length > 0) {
        const randomCell = availableCells[Math.floor(Math.random() * availableCells.length)];
        makeMove(randomCell, 'O');
    }
}

// Find Winning Move
function findWinningMove(player) {
    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        const cells = [gameState[a], gameState[b], gameState[c]];
        
        if (cells.filter(cell => cell === player).length === 2 && cells.includes('')) {
            if (gameState[a] === '') return a;
            if (gameState[b] === '') return b;
            if (gameState[c] === '') return c;
        }
    }
    return -1;
}